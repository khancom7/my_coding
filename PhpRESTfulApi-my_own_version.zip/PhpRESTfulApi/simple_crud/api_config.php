<?php
$conn = mysqli_connect('localhost', 'root', '', 'db_api_test') or die("Connection Failed");
