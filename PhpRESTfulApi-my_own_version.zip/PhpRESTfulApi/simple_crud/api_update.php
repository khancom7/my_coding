<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: PUT');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

$data = json_decode(file_get_contents("php://input"), true);

$cust_id = $data['cust_id'];
$cust_firstname = $data['cust_firstname'];
$cust_lastname = $data['cust_lastname'];
$cust_phone = $data['cust_phone'];
$cust_address = $data['cust_address'];

include "api_config.php";

$sql = "UPDATE `tbl_customers` SET `FirstName` = '{$cust_firstname}', `LastName` = '{$cust_lastname}', `Phone` = '{$cust_phone}', `Address` = '{$cust_address}' WHERE `Cust_ID` = {$cust_id}";

if (mysqli_query($conn, $sql)) {
    echo json_encode(array('message' => 'Record Successfully Updated', 'status' => true));
} else {
    echo json_encode(array('message' => 'Record Not Updated.', 'status' => false));
}
