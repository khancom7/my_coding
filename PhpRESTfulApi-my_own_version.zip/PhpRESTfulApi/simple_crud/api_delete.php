<?php

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: DELETE');
header('Access-Control-Allow-Headers: Access-Control-Allow-Headers, Content-Type, Access-Control-Allow-Methods, Authorization, X-Requested-With');

$data = json_decode(file_get_contents("php://input"), true);

$cust_id = $data['cust_id'];

include "api_config.php";

$sql = "DELETE FROM `tbl_customers` WHERE `Cust_ID` = {$cust_id}";

if (mysqli_query($conn, $sql)) {
    echo json_encode(array('message' => 'Record Successfully Deleted.', 'status' => true));
} else {
    echo json_encode(array('message' => 'Record Not Deleted.', 'status' => false));
}
